<?php
class FeedEnclosure {
	public $link;
	public $type;
	public $length;
}
?>
